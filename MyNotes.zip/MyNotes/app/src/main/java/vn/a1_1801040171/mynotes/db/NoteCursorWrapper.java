package vn.a1_1801040171.mynotes.db;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import vn.a1_1801040171.mynotes.model.Note;

public class NoteCursorWrapper extends CursorWrapper {
    /**
     * Creates a cursor wrapper.
     *
     * @param cursor The underlying cursor to wrap.
     */
    public NoteCursorWrapper(Cursor cursor) {

        super(cursor);
    }
    public Note getNote(){
        String text=getString(getColumnIndex(DbSchema.NotesTable.Cols.TEXT));
        Note note = new Note(text);
        note.setId(getLong(getColumnIndex(DbSchema.NotesTable.Cols.ID)));
        return note;
    }
    public Note getANote(){
        moveToFirst();
        if(getCount()==0){
            return null;
        }
        Note note = null;
        String text=getString(getColumnIndex(DbSchema.NotesTable.Cols.TEXT));
        if(text!=null){
            note = new Note(text);
            note.setId(getLong(getColumnIndex(DbSchema.NotesTable.Cols.ID)));
        }
        return note;

    }
    public List<Note> getNotes(){
        List<Note> notes = new ArrayList<>();
        moveToFirst();
        while(!isAfterLast()){
            Note note = getNote();
            notes.add(note);
            moveToNext();
        }
        return notes;
    }
}
