package vn.a1_1801040171.mynotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import vn.a1_1801040171.mynotes.db.NoteManager;
import vn.a1_1801040171.mynotes.model.Note;

public class EditNoteActivity extends AppCompatActivity {

    private EditText editNoteTv;
    private Note note;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        //get intent to extract in4
        Intent intent= getIntent();
        Long id=intent.getLongExtra("ID",0);

        // get Note from database
        note = NoteManager.getInstance(this).findNoteById(id);
        //display note in TextView
        editNoteTv = findViewById(R.id.editNoteTv);
        editNoteTv.setText(note.getText());
    }
    public void onBackPressed(){
        note.setText(editNoteTv.getText().toString());
        NoteManager.getInstance(this).update(note);
        Intent intent = new Intent(this, MainActivity.class);
        setResult(RESULT_OK);
        super.onBackPressed();
    }


}