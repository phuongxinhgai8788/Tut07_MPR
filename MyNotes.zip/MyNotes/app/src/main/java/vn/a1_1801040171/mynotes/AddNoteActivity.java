package vn.a1_1801040171.mynotes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import vn.a1_1801040171.mynotes.db.NoteManager;
import vn.a1_1801040171.mynotes.model.Note;

public class AddNoteActivity extends AppCompatActivity {
    private EditText addNoteTv;
    private Note note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);
        addNoteTv = findViewById(R.id.addNoteTv);

    }
    public void onBackPressed(){
        String noteText = addNoteTv.getText().toString();
        note = new Note(noteText);
        NoteManager.getInstance(this).add(note);
        setResult(RESULT_OK);
        super.onBackPressed();
    }
   }