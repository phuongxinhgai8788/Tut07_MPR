package vn.a1_1801040171.mynotes.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.List;

import vn.a1_1801040171.mynotes.model.Note;

public class NoteManager {
    private static NoteManager instance;
    private static final String INSERT="INSERT INTO "+
            DbSchema.NotesTable.NAME +"("+DbSchema.NotesTable.Cols.TEXT+")" +
            " VALUES (?)";

    private DbHelper dbHelper;
    private SQLiteDatabase db;

    public static NoteManager getInstance(Context context){
        if(instance==null){
           instance=new NoteManager(context);

        }
        return instance;
    }
    private NoteManager(Context context){
        dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public  DbHelper getDbHelper(){
        return this.dbHelper;
    }
   /* public SQLiteDatabase getSQLiteDatabase(){
        return this.getSQLiteDatabase();
    }*/
    public List<Note> all(){
        String sql="SELECT*FROM "+DbSchema.NotesTable.NAME;
        Cursor cursor = db.rawQuery(sql, null);
        NoteCursorWrapper noteCursorWrapper=new NoteCursorWrapper(cursor);
        return noteCursorWrapper.getNotes();
    }
    public Note findNoteById(Long id){
        String sql="SELECT * FROM "+ DbSchema.NotesTable.NAME
                +" WHERE id = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{id+""});
        NoteCursorWrapper noteCursorWrapper=new NoteCursorWrapper(cursor);
        return noteCursorWrapper.getANote();
    }
    public boolean update(Note note){
        ContentValues contentValues = new ContentValues();
        Long id=note.getId();
        String idString=String.valueOf(id);
        String text=note.getText();
        contentValues.put(DbSchema.NotesTable.Cols.TEXT, text);
        db.update(DbSchema.NotesTable.NAME, contentValues,"id = ?", new String[]{idString});
        return true;
    }
    public boolean add(Note note){
        SQLiteStatement statement= db.compileStatement(INSERT);

        statement.bindString(1, note.getText());
        long id= statement.executeInsert();

        if(id>0){
            note.setId(id);
            Log.d("ADD_OCCURENCE", id+"");
            return true;
        }
        return false;
    }
    public boolean delete(Long id){
       // String sql= " DELETE FROM "+DbSchema.NotesTable.NAME+" WHERE id= ?";
        // Cursor cursor = db.rawQuery(sql, new String[]{id+""});
        int result = db.delete(DbSchema.NotesTable.NAME, "id= ?", new String[]{id+""});
        return result>0;
    }
}
