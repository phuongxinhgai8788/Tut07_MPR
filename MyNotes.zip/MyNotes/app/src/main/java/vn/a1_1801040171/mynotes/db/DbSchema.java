package vn.a1_1801040171.mynotes.db;

public class DbSchema {
    public final class NotesTable{
        public static final String NAME="another_notes";
        public final class Cols{
            public static final String TEXT ="text";
            public static final String ID="id";

        }
    }
}
