package vn.a1_1801040171.mynotes.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME ="notes.db";
    public static final int DB_VERSION = 2;
    public DbHelper(@Nullable Context context) {

        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create table
        db.execSQL(" CREATE TABLE "+DbSchema.NotesTable.NAME+"(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                DbSchema.NotesTable.Cols.TEXT+" TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop existing table
        db.execSQL("DROP TABLE IF EXISTS "+DbSchema.NotesTable.NAME);
        //Create a new one
        onCreate(db);

    }
}
