package vn.a1_1801040171.mynotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

import vn.a1_1801040171.mynotes.db.DbHelper;
import vn.a1_1801040171.mynotes.db.NoteManager;
import vn.a1_1801040171.mynotes.model.Note;

public class MainActivity extends AppCompatActivity {
    public static final int NOTE_ADDED = 1;
    public static final int NOTE_EDITTED = 2;

    private RecyclerView recyclerView;
    private List<Note> noteList;
    private NoteManager noteManager;
    private NoteAdapter noteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //dataset
        noteManager = NoteManager.getInstance(this);
       // DbHelper  dbHelper=noteManager.getDbHelper();
       // dbHelper.onCreate(noteManager.getSQLiteDatabase());
        noteList=noteManager.all();
        noteList = noteManager.all();

        //adapter
        noteAdapter = new NoteAdapter(noteList);

        // recycler view
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setAdapter(noteAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        //DbHelper dbHelper = new DbHelper(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(this, AddNoteActivity.class);
        startActivityForResult(intent, NOTE_ADDED);
        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK && (requestCode == NOTE_ADDED || requestCode == NOTE_EDITTED)){
            noteList.clear();
            noteList.addAll(noteManager.all());
            noteAdapter.notifyDataSetChanged();
        }
    }
}