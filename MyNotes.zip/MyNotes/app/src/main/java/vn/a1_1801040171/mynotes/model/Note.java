package vn.a1_1801040171.mynotes.model;

import java.io.Serializable;

public class Note implements Serializable {
    private long id;
    private String text;
    // data from the database
    public Note(int id, String text) {
        this.id = id;
        this.text = text;
    }
    // data from the form
    public Note(String text){
        this.text=text;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
