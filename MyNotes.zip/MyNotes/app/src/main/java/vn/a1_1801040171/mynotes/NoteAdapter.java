package vn.a1_1801040171.mynotes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.a1_1801040171.mynotes.db.NoteManager;
import vn.a1_1801040171.mynotes.model.Note;

public class NoteAdapter extends RecyclerView.Adapter {
    private List<Note> notes;
    private Context context;

    public NoteAdapter(List<Note> notes){
        this.notes = notes;
    }

    @Override
    public NoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View noteView = LayoutInflater.from(context).inflate(R.layout.item_note, parent,false);
        return new NoteHolder(noteView, context);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Note note = notes.get(position);
        NoteHolder holder2 = (NoteHolder) holder;
        holder2.bind(note);
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public class NoteHolder extends RecyclerView.ViewHolder {
        private TextView textView;
        public NoteHolder(@NonNull View itemView, Context context) {
            super(itemView);
            textView=itemView.findViewById(R.id.textView);
        }

        public void bind(Note note) {

            textView.setText(note.getText());
            itemView.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, EditNoteActivity.class);
                    intent.putExtra("ID", note.getId());
                    Activity main = (Activity) context;
                    main.startActivityForResult(intent,2);
                }
            });

            textView.setOnLongClickListener(new View.OnLongClickListener(){

                @Override
                public boolean onLongClick(View v) {
                    new AlertDialog.Builder(context)
                            .setTitle("Delete?")
                            .setMessage("Are you sure?")
                            .setPositiveButton("No", new DialogInterface.OnClickListener(){
                                public void onClick(DialogInterface dialog, int which){
                                    dialog.cancel();
                                }
                            })
                            .setNegativeButton("Yes", new DialogInterface.OnClickListener(){

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    NoteManager.getInstance(context).delete(note.getId());
                                    notes = NoteManager.getInstance(context).all();
                                    notifyDataSetChanged();
                                }
                            })
                             .show();
                    return true;

                }

            });

        }
    }
}
